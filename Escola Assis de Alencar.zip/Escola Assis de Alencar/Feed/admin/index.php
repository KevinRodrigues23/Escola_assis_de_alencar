<?php
session_start();
require '../../assets/conexao.php';
require '../config.php';
include '../src/Artigo.php';



$artigo = new Artigo($mysql);
$artigos = $artigo->exibirTodos();

?>
<!DOCTYPE html >
<html lang="pt-br" >

<head>
    <title>Página administrativa</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" 
    integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!-- font icons from bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>


<body >
<?php 
    include('layout/headerAdmin.php');
    ?>




    <div id="container">
        <h1>Página Administrativa</h1>
        
        <table class="table">
  <caption>Imprimir <i class="fa fa-id-card-o" aria-hidden="true"></i></caption>
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">PROFESSOR</th>
      <th scope="col">TITULO</th>
      <th scope="col">RELATOR</th>
      <th scope="col">EDITAR</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($artigos as $art) { ?>
    <tr>
      <th scope="row"><?php echo $art['id']; ?></th>
      <td><?php echo $art['nome']; ?></td>
      <td><?php echo $art['titulo']; ?></td>
      <td><?php echo $art['conteudo']; ?></td>
      <td>
     <a class="botao" href="editar-artigo.php?id=<?php echo $art['id']; ?>">Editar <i class="fa fa-pencil" aria-hidden="true"></i></a>
     <a class="botao" href="excluir-artigo.php?id=<?php echo $art['id']; ?>">Excluir <i class="fa fa-trash" aria-hidden="true"></i></a>
    </td>
    </tr>
    <?php } ?>
  </tbody>
</table>
       
    </div>

    <?php 
    include('../layout/footer.php');
    ?>
</body>

</html>