<?php	
   

    require __DIR__.'/../../vendor/autoload.php';
    use Dompdf\Dompdf;
    use Dompdf\Options;

    $options = new options();
    $options->setChroot(__DIR__);
    
    




?>